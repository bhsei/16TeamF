package us.codecraft.tinyioc.context;

import us.codecraft.tinyioc.beans.factory.BeanFactory;

/**
 * @author yihua.huang@dianping.com
 */
public interface ApplicationContext extends BeanFactory {
}
