package us.codecraft.tinyioc;


public interface OutputService {
    void output(String text);
}
