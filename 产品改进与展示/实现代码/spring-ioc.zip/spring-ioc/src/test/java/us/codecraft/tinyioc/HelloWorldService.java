package us.codecraft.tinyioc;


public interface HelloWorldService {

    void helloWorld();
}
